polyconvert --net-file kirchberg.net.xml --osm-files kirchberg.osm.xml  --typemap typesmap.xml -o kirchberg.shapes.xml
